<?php

return [
    'admin' => [

    ],
    
    'customer' => [

    ]
];

?>